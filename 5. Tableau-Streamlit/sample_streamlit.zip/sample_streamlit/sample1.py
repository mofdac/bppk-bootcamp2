import streamlit as st

def main():
    """App with Streamlit"""
    st.title("Hello Data Analyst!")
    
if __name__=='__main__':
    main()
